package tf.ferhat.taschenrechner;


import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;


//used by room to access the database
//database access object?
@Dao
public interface ToDoEntryDao {
    @Query("SELECT * FROM ToDoEntries ORDER BY id ASC")
    LiveData<List<ToDoEntry>> getAll();

    @Query("SELECT * FROM ToDoEntries WHERE title LIKE :title")
    ToDoEntry findByTitle(String title);

    @Query("SELECT * FROM ToDoEntries WHERE id LIKE :id")
    ToDoEntry findById(int id);

    @Query("DELETE FROM ToDoEntries")
    void deleteAll();

    @Query("DELETE FROM ToDoEntries WHERE id LIKE :id")
    void deleteById(int id);

    @Insert
    void insert(ToDoEntry entry);


}
