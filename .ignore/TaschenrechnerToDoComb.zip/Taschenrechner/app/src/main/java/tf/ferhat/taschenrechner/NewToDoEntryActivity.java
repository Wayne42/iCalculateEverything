package tf.ferhat.taschenrechner;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class NewToDoEntryActivity extends AppCompatActivity {

    private EditText mEditTitleView;
    private EditText mEditDescriptionView;
    private EditText mEditDateView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_todoentry);

        mEditTitleView = findViewById(R.id.edit_title);
        mEditDescriptionView = findViewById(R.id.edit_description);
        mEditDateView = findViewById(R.id.edit_date);

        final Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent replyIntent = new Intent();
                if (TextUtils.isEmpty(mEditTitleView.getText()) || TextUtils.isEmpty(mEditDescriptionView.getText()) || TextUtils.isEmpty(mEditDateView.getText())  ) { //check if empty
                    setResult(RESULT_CANCELED, replyIntent);
                } else {
                    String title = mEditTitleView.getText().toString();
                    String description = mEditDescriptionView.getText().toString();
                    String date = mEditDateView.getText().toString();

                    replyIntent.putExtra("title", title);
                    replyIntent.putExtra("desc", description);
                    replyIntent.putExtra("date", date);

                    setResult(RESULT_OK, replyIntent);
                }
                finish();
            }
        });
    }
}