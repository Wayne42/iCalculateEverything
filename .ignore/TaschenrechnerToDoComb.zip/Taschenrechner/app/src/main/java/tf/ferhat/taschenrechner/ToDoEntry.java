package tf.ferhat.taschenrechner;


import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

/* SQL Table Structure for ToDoEntry Objects defined here*/


@Entity(tableName = "ToDoEntries")
public class ToDoEntry {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "title")
    public String title;

    @ColumnInfo(name = "description")
    public String description;

    @ColumnInfo(name = "duetodate")
    public String duetodate;


    public ToDoEntry (String title, String description,String duetodate){
        this.title = title;
        this.description = description;
        this.duetodate = duetodate;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDuetodate() {
        return duetodate;
    }

    public void setId(int id){
        this.id = id;
    }

}

