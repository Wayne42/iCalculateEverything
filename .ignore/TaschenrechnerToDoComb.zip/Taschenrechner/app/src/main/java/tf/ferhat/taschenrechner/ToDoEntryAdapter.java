package tf.ferhat.taschenrechner;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class ToDoEntryAdapter extends RecyclerView.Adapter<ToDoEntryAdapter.ToDoEntryViewHolder> {

    class ToDoEntryViewHolder extends RecyclerView.ViewHolder {
        private final TextView toDoEntryItemView;
        private final TextView toDoEntryItemView2;

        private ToDoEntryViewHolder(View itemView) {
            super(itemView);
            toDoEntryItemView = itemView.findViewById(R.id.textView);
            toDoEntryItemView2 = itemView.findViewById(R.id.textView2);
        }
    }

    private final LayoutInflater mInflater;
    private List<ToDoEntry> mToDoEntries; // Cached copy of toDoEntries

    ToDoEntryAdapter(Context context) { mInflater = LayoutInflater.from(context); }

    @Override
    public ToDoEntryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new ToDoEntryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ToDoEntryViewHolder holder, int position) {
        if (mToDoEntries != null) {
            ToDoEntry current = mToDoEntries.get(position);
            holder.toDoEntryItemView.setText(current.getTitle());
            holder.toDoEntryItemView2.setText(current.getDuetodate());
        } else {
            // Covers the case of data not being ready yet.
            holder.toDoEntryItemView.setText("No ToDoEntry");
        }
    }

    void setToDoEntrys(List<ToDoEntry> toDoEntries){
        mToDoEntries = toDoEntries;
        notifyDataSetChanged();
    }

    // getItemCount() is called many times, and when it is first called,
    // mToDoEntrys has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (mToDoEntries != null)
            return mToDoEntries.size();
        else return 0;
    }
}