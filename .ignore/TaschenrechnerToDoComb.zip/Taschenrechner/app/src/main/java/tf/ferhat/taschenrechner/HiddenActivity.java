package tf.ferhat.taschenrechner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HiddenActivity extends AppCompatActivity {
    private ToDoEntryViewModel mToDoEntryViewModel;
    public static final int NEW_TODOENTRY_ACTIVITY_REQUEST_CODE = 1;
    private TextView entryCounterTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hidden);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        final ToDoEntryAdapter adapter = new ToDoEntryAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        entryCounterTextView = findViewById(R.id.entryCounterTextView);

        mToDoEntryViewModel = ViewModelProviders.of(this).get(ToDoEntryViewModel.class);
        mToDoEntryViewModel.getAll().observe(this, new Observer<List<ToDoEntry>>() {
            @Override
            public void onChanged(@Nullable final List<ToDoEntry> toDoEntries) {
                // Update the cached copy of the entries in the adapter.
                adapter.setToDoEntrys(toDoEntries);
                entryCounterTextView.setText(adapter.getItemCount()+"");
            }
        });

        //fab button
        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HiddenActivity.this, NewToDoEntryActivity.class);
                        startActivityForResult(intent, NEW_TODOENTRY_ACTIVITY_REQUEST_CODE);
                    }
                }
        );

        //delete all entries button
        Button delButton = findViewById(R.id.buttonDeleteAllEntries);
        delButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    /*
    * In MainActivity, add the onActivityResult() code for the NewToDoEntryActivity.
If the activity returns with RESULT_OK, insert the returned word into the database by calling the insert() method of the ToDoEntryViewModel.
    * */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == NEW_TODOENTRY_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            ToDoEntry entry = new ToDoEntry(data.getStringExtra("title"), data.getStringExtra("desc"), data.getStringExtra("date"));
            mToDoEntryViewModel.insert(entry);
        } else {
            Toast.makeText(
                    getApplicationContext(),
                    "Empty input, not saved",
                    Toast.LENGTH_LONG).show();
        }
    }
}
