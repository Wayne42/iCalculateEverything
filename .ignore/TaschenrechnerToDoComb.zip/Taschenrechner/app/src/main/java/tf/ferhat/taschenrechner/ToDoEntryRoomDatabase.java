package tf.ferhat.taschenrechner;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {ToDoEntry.class}, version = 1)
public abstract class ToDoEntryRoomDatabase extends RoomDatabase {
    public abstract ToDoEntryDao toDoEntryDao();


    //Make the RoomDatabase a singleton to prevent having multiple instances of the database opened at the same time.
    private static volatile ToDoEntryRoomDatabase INSTANCE;

    static ToDoEntryRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (ToDoEntryRoomDatabase.class) {
                if (INSTANCE == null) {
                    // Create database here
                    //Add the code to get a database. This code uses Room's database builder to create a RoomDatabase object in the application context from the ToDoEntryRoomDatabase class and names it "todoentry_database".
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            ToDoEntryRoomDatabase.class, "todoentry_database")//
                            //.addCallback(sRoomDatabaseCallback) //optional callback to populate db with entries after deleting everthing in db
                            .build();

                }
            }
        }
        return INSTANCE;
    }


    //BLACK MAGIC TO POPULATE DB ON EVERY APPSTART

    /*
There is no data in the database. You will add data in two ways: Add some data when the database is opened, and add an Activity for adding words.

To delete all content and repopulate the database whenever the app is started, you create a RoomDatabase.Callback and override onOpen(). Because you cannot do Room database operations on the UI thread, onOpen() creates and executes an AsyncTask to add content to the database.

Here is the code for creating the callback in the WordRoomDatabase class:


     */
    private static RoomDatabase.Callback sRoomDatabaseCallback =
            new RoomDatabase.Callback(){

                @Override
                public void onOpen (@NonNull SupportSQLiteDatabase db){
                    super.onOpen(db);
                    new PopulateDbAsync(INSTANCE).execute();
                }
            };


    /*
    *
    * Here is the code for the AsyncTask that deletes the contents of the database, then populates it with the two words "Hello" and "World". Feel free to add more words!
    * */
    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

        private final ToDoEntryDao mDao;

        PopulateDbAsync(ToDoEntryRoomDatabase db) {
            mDao = db.toDoEntryDao();
        }

        @Override
        protected Void doInBackground(final Void... params) {
            mDao.deleteAll();
            ToDoEntry entry = new ToDoEntry("Hello", "World", "today");
            mDao.insert(entry);
            entry = new ToDoEntry("Hello2", "World2", "tomorrow");
            mDao.insert(entry);
            return null;
        }
    }



}




