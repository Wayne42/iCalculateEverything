package tf.ferhat.icalculateeverything;

import android.content.Intent;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class AboutActivity  extends AppCompatActivity {

    private TextView header;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);


        header = findViewById(R.id.headerAboutActivity);
        header.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRect(-50, -1, view.getWidth() + 50, view.getHeight());

            }
        });
        Button Donate = findViewById(R.id.button_donate);
        Donate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.paypal.com/donate/?token=ctcwACmreIDeaJCn-Luso3Qe-o8y9JY8DXpWJSEPBZVRjkGUjjztGXxTL8gbs1tyynLmCW&country.x=DE&locale.x=DE"));
                startActivity(browserIntent);
            }
        });
    }
}
